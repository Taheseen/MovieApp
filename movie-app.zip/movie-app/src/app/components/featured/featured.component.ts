import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../../services/movies.service';

@Component({
  selector: 'app-featured',
  templateUrl: './featured.component.html',
  styleUrls: ['./featured.component.css'],
  providers: [MoviesService]
})
export class FeaturedComponent implements OnInit {
  searchParam: string;
  movieList;
  constructor(
    private _moviesService: MoviesService
  ) { }

  ngOnInit() {
    this.featuredMovies();
  }

  featuredMovies() {
    this._moviesService.getFeaturedMovies()
      .subscribe(response => {
        this.movieList = response;
      });
  }
}

import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../../services/movies.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [MoviesService]
})
export class SearchComponent implements OnInit {
  searchParam: string;
  showPanel: boolean;
  showText: boolean;
  statusMessage: string;
  actorName: string[];
  movieList: any = {};
  config: any = {};
  constructor(
     private _moviesService: MoviesService
  ) { }

  ngOnInit() {
    this.showPanel = false;
    this.showText = false;
  }


  searchMovies() {
    this._moviesService.getMovies(this.searchParam)
      .subscribe(response => {
        this.movieList = response;
        if ( this.movieList.Response === 'False') {
          this.showPanel = false;
          this.statusMessage = this.movieList.Error;
        } else {
          this.showPanel = true;
          this.statusMessage = '';
        }
        // to show string values in list
        this.actorName = this.movieList.Actors.split(',', this.movieList.Actors.length);

        // show hide more charectors
        this.config.showChars = 200;
        this.config.lessText = this.movieList.Plot.substr(0, this.config.showChars);
        this.config.moreText = this.movieList.Plot.substr(this.config.showChars, this.movieList.length);
      },
      (error) => {
        this.showPanel = false;
        this.statusMessage = 'error occured';
      }
    )
      ;
  }
  toggleText() {
    this.showText = !this.showText;
  }
}

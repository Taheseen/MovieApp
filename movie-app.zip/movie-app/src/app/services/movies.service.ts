import { Http, HttpModule } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class MoviesService {
  private url: string;
  plot = 'full';
  constructor( private _http: Http) { }

  getMovies(searchParam: string) {
    this.url = 'http://www.omdbapi.com/?t=' + searchParam + '&plot=' + this.plot + '&apikey=6c3a2d45';
    return this._http.get(this.url).map(response => response.json())
                     .catch(this.handleError);
  }

  private handleError(error: Response) {
   // console.error(error);
    return Observable.throw(error);
 }
  getFeaturedMovies() {
    this.url = 'assets/json/featured.json';
    return this._http.get(this.url).map(response => response.json());
  }
}

export interface Movies {
  Title: string;
}
